 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOImplement;
import java.util.List;
import model.*;
/**
 *
 * @author LENOVO
 */
public interface dataadminimplement {
    public void insert(dataadmin a);
    public void insert1(dataadmin a);
    public void update(dataadmin a);
    public void delete(String username);
    public List<dataadmin> getAll();
}
