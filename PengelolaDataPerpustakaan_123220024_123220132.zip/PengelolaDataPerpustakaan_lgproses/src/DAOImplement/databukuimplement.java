/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package DAOImplement;
import java.util.List;
import model.*;
/**
 *
 * @author LENOVO
 */
public interface databukuimplement {
    public void insert(databuku b);
    public void update(databuku b);
    public void delete(String id_buku);
    public List<databuku> getAll();
    public List<databuku> search(String judul_buku);
}
