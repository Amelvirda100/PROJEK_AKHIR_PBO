/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAOPerpustakaan;
import java.sql.*;
import java.util.*;
import koneksi.connector;
import model.*;
import DAOImplement.datariwayatimplement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author ACER
 */
public class datariwayatpeminjamDAO implements datariwayatimplement{
     Connection connection;
    final String select = "SELECT nik, nama, id_buku, judul_buku, tanggal_pinjam, tanggal_kembali FROM riwayat"; 
    final String delete = "delete from riwayat where nik=?";
    
    public datariwayatpeminjamDAO(){
        connection = connector.connection();
    } 
     @Override
    public void delete(String nik) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(delete);
            statement.setString(1, nik);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<datariwayat> getAll() {
        List<datariwayat> dr = null;
        try{
            dr = new ArrayList<datariwayat>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while(rs.next()){
                datariwayat riwayat = new datariwayat();
                riwayat.setNik(rs.getString("nik"));
                riwayat.setNama(rs.getString("nama"));
                riwayat.setId_buku(rs.getString("id_buku"));
                riwayat.setJudul_buku(rs.getString("judul_buku"));
                riwayat.setTanggal_pinjam(rs.getString("tanggal_pinjam"));
                riwayat.setTanggal_kembali(rs.getString("tanggal_kembali"));
                dr.add(riwayat);
            }
        }catch(SQLException ex){
            Logger.getLogger(datariwayatDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dr;
    }

    @Override
    public void insert(datariwayat r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(datariwayat r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
