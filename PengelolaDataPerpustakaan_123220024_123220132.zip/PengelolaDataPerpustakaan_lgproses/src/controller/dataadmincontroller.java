/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.List;
import DAOPerpustakaan.dataadminDAO;
import DAOImplement.dataadminimplement;
import model.*;
import view.MainViewAdmin;
import view.MainViewRegister;
import view.MainViewDaftar;
/**
 *
 * @author LENOVO
 */
public class dataadmincontroller {
    MainViewAdmin frame;
    MainViewRegister frame1;
    MainViewDaftar frame2;
    dataadminimplement impldataadmin;
    List<dataadmin> da;
    public dataadmincontroller(MainViewAdmin frame){
        this.frame = frame;
        impldataadmin = new dataadminDAO();
        da = impldataadmin.getAll();
    }
    public void isitabel(){
        da = impldataadmin.getAll();
        modeltabeldataadmin ma = new modeltabeldataadmin(da);
        frame.getTabeldataadmin().setModel(ma);
    }
    public dataadmincontroller(MainViewRegister frame){
        this.frame1 = frame;
        impldataadmin = new dataadminDAO();
        da = impldataadmin.getAll();
    }
    public dataadmincontroller(MainViewDaftar frame){
        this.frame2 = frame;
        impldataadmin = new dataadminDAO();
        da = impldataadmin.getAll();
    }
    public boolean isUsernameExists(String username) {
    for (dataadmin admin : da) {
        if (admin.getUsername().equals(username)) {
            return true; // Jika username sudah ada, kembalikan true
        }
    }
    return false; // Jika username belum ada, kembalikan false
    }
    public boolean authenticate(String username, String password) {
    for (dataadmin admin : da) {
        if (admin.getUsername().equals(username) && admin.getPassword().equals(password)) {
            return true; // Jika username sudah ada, kembalikan true
        }
    }
    return false;
    }
    public void insert(){
        dataadmin da = new dataadmin();
        da.setUsername(frame1.getjTextregisterusername().getText());
        da.setPassword(new String(frame1.getjPasswordregister().getPassword()));
        impldataadmin.insert(da);
        
        frame1.getjTextregisterusername().setText("");
        frame1.getjPasswordregister().setText("");
    }
    public void insert1(){
        dataadmin da = new dataadmin();
        da.setUsername(frame.getjTexteditusername().getText());
        da.setPassword(frame.getjTexteditpassword().getText());
        impldataadmin.insert(da);
    }
    public void update(){
        dataadmin da = new dataadmin();
        da.setUsername(frame.getjTexteditusername().getText());
        da.setPassword(frame.getjTexteditpassword().getText());
        impldataadmin.update(da);
    }
}
