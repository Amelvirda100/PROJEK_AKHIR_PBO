/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;


import java.util.List;
import DAOPerpustakaan.datariwayatpeminjamDAO;
import DAOImplement.datariwayatimplement;
import model.*;
import view.MainViewRiwayatPeminjam;

public class datariwayatpeminjamcontroller {
    MainViewRiwayatPeminjam frame;
    datariwayatimplement impldatariwayat;
    List<datariwayat> dr;
    
    public datariwayatpeminjamcontroller(MainViewRiwayatPeminjam frame){
        this.frame = frame;
        impldatariwayat = new datariwayatpeminjamDAO();
        dr = impldatariwayat.getAll();
    }
    public void isitabbel(){
        dr =impldatariwayat.getAll();
        modeltabelriwayatpeminjam mp = new modeltabelriwayatpeminjam(dr);
        frame.getTabelriwayatpeminjam().setModel(mp);
    }
     public void delete(String nik) {
        impldatariwayat.delete(nik);
    
        frame.getjTextnik().setText("");
        frame.getjTextnama().setText("");
        frame.getjTextid().setText("");
        frame.getjTextjudul().setText("");
        frame.getjTexttanggalpinjam().setText("");
        frame.getjTexttanggalkembali().setText("");
    }
}
