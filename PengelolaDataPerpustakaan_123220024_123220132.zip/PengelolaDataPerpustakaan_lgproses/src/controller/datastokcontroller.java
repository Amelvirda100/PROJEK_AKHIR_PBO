/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.List;
import DAOPerpustakaan.datastokDAO;
import DAOImplement.databukuimplement;
import model.*;
import view.MainViewStok;
/**
 *
 * @author LENOVO
 */
public class datastokcontroller {
    MainViewStok frame;
    databukuimplement impldatabuku;
    List<databuku> db;
    
    public datastokcontroller(MainViewStok frame){
        this.frame = frame;
        impldatabuku = new datastokDAO();
        db= impldatabuku.getAll();
    }
    public void isitabbel(){
        db =impldatabuku.getAll();
        modeltabeldatastok mb = new modeltabeldatastok(db);
        frame.getTabeldatastok().setModel(mb);
    }
    public void insert(){
        databuku db = new databuku();
        db.setId_buku(frame.getjTextid().getText());
        db.setJudul_buku(frame.getjTextjudul().getText());
        db.setStock(Integer.parseInt(frame.getjTextstock().getText()));
        impldatabuku.insert(db);
        
        frame.getjTextid().setText("");
        frame.getjTextjudul().setText("");
        frame.getjTextstock().setText("");
    }
    public void update(){
        databuku db = new databuku();
        db.setId_buku(frame.getjTextid().getText());
        db.setJudul_buku(frame.getjTextjudul().getText());
        db.setStock(Integer.parseInt(frame.getjTextstock().getText()));
        impldatabuku.update(db);
        
        frame.getjTextid().setText("");
        frame.getjTextjudul().setText("");
        frame.getjTextstock().setText("");
    }
    public void delete(String id_buku) {
    impldatabuku.delete(id_buku);
    
    frame.getjTextid().setText("");
    frame.getjTextjudul().setText("");
    frame.getjTextstock().setText("");
    }
}
