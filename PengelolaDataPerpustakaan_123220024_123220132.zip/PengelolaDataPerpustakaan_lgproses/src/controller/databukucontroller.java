/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.util.List;
import DAOPerpustakaan.databukuDAO;
import DAOImplement.databukuimplement;
import model.*;
import view.MainViewBuku;
/**
 *
 * @author LENOVO
 */
public class databukucontroller {
    MainViewBuku frame;
    databukuimplement impldatabuku;
    List<databuku> db;
    
    public databukucontroller(MainViewBuku frame){
        this.frame = frame;
        impldatabuku = new databukuDAO();
        db= impldatabuku.getAll();
    }
    public void isitabbel(){
        db =impldatabuku.getAll();
        modeltabeldatabuku mb = new modeltabeldatabuku(db);
        frame.getTabeldatabuku().setModel(mb);
    }
    public void insert(){
        databuku db = new databuku();
        db.setId_buku(frame.getjTextid().getText());
        db.setJudul_buku(frame.getjTextjudul().getText());
        db.setPenerbit(frame.getjTextpenerbit().getText());
        db.setTahun_terbit(Integer.parseInt(frame.getjTexttahun().getText()));
        db.setPenulis(frame.getjTextpenulis().getText());
        int stock=0;
        db.setStock(stock);
        impldatabuku.insert(db);
        
        frame.getjTextid().setText("");
        frame.getjTextjudul().setText("");
        frame.getjTextpenerbit().setText("");
        frame.getjTexttahun().setText("");
        frame.getjTextpenulis().setText("");
        frame.getjTextstock().setText("");
    }
    public void update(){
        databuku db = new databuku();
        db.setId_buku(frame.getjTextid().getText());
        db.setJudul_buku(frame.getjTextjudul().getText());
        db.setPenerbit(frame.getjTextpenerbit().getText());
        db.setTahun_terbit(Integer.parseInt(frame.getjTexttahun().getText()));
        db.setPenulis(frame.getjTextpenulis().getText());
        impldatabuku.update(db);
        
        frame.getjTextid().setText("");
        frame.getjTextjudul().setText("");
        frame.getjTextpenerbit().setText("");
        frame.getjTexttahun().setText("");
        frame.getjTextpenulis().setText("");
    }
    public void delete(String id_buku) {
    impldatabuku.delete(id_buku);
    
    frame.getjTextid().setText("");
    frame.getjTextjudul().setText("");
    frame.getjTextpenerbit().setText("");
    frame.getjTexttahun().setText("");
    frame.getjTextpenulis().setText("");
    }
    

    public void search() {
        String judul_buku =(frame.getjTextFieldsearchbuku().getText());
        List<databuku> dp = impldatabuku.search(judul_buku);
        modeltabeldatabuku mp = new modeltabeldatabuku(dp);
        frame.getTabeldatabuku().setModel(mp);
    }
    
}
