/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author LENOVO
 */
public class modeltabeldatastok extends AbstractTableModel{
    List<databuku> db;
    private final String[] columnNames = {"ID_BUKU", "JUDUL_BUKU", "STOCK"};
    public modeltabeldatastok(List<databuku>db){
        this.db = db;
    }

    @Override
    public int getRowCount() {
        return db.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    @Override
    public String getColumnName(int columnIndex){
        return columnNames[columnIndex];
    }
    
    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return db.get(row).getId_buku();
            case 1:
                return db.get(row).getJudul_buku();
            case 2:
                return db.get(row).getStock();
            default:
                return null;
    }
    }
}
