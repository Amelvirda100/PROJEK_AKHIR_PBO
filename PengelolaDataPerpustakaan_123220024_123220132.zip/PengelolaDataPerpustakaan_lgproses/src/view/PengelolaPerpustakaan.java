/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

/**
 *
 * @author LENOVO
 */
public class PengelolaPerpustakaan {
    public static void main(String[] args) {
        // TODO code application logic here
        MainViewDaftar v = new MainViewDaftar();
        v.setVisible(true);
        v.setLocationRelativeTo(null);
    }
}
