-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 31, 2024 at 06:37 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan_pbo`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('ikhsan', 'pass.123'),
('qwe', '111'),
('ritz', '1212'),
('nana', '123333'),
('wira', '67r'),
('wewr', '11112'),
('gttrtet', '1234232'),
('gtt', '153544345jj'),
('gttwqw', '34'),
('apa', '153432'),
('ikhsan', '132123'),
('ikhsan', '2'),
('ikhsann', '2'),
('ikhsan', '1'),
('ikhsan', '3'),
('ikhsan', '123'),
('ikhsan', '2'),
('ikhsan', ''),
('ikhsan', 'y'),
('ikhsan', ''),
('ser', '2we'),
('windah', 'basudara'),
('windah', 'basudara'),
('windah', '1'),
('falihd', 'falihdd'),
('windy', '233e'),
('ernest', '2w3e3e');

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` varchar(50) NOT NULL,
  `judul_buku` varchar(100) NOT NULL,
  `penerbit` varchar(100) NOT NULL,
  `tahun_terbit` year(4) NOT NULL,
  `penulis` varchar(50) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `judul_buku`, `penerbit`, `tahun_terbit`, `penulis`, `stock`) VALUES
('3', 'Ramadan tiba', 'P', '2020', 'A', 0),
('4', 'Ramadan tiba', 'P', '2020', 'AB', 0),
('s4RTs4', 'IBUKU SAYANG', 'RAMADHAN INDUSTRY', '2024', 'IKHSAN SYAHRI RAMADHAN', 80);

-- --------------------------------------------------------

--
-- Table structure for table `riwayat`
--

CREATE TABLE `riwayat` (
  `nik` varchar(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `id_buku` varchar(50) NOT NULL,
  `judul_buku` varchar(100) NOT NULL,
  `tanggal_pinjam` date NOT NULL,
  `tanggal_kembali` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `riwayat`
--

INSERT INTO `riwayat` (`nik`, `nama`, `id_buku`, `judul_buku`, `tanggal_pinjam`, `tanggal_kembali`) VALUES
('132', 'virda', '12', 'Melihat Warna Musik', '2024-01-05', '2024-08-05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`);

--
-- Indexes for table `riwayat`
--
ALTER TABLE `riwayat`
  ADD PRIMARY KEY (`nik`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
